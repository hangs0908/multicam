DESC userinfo;
select * from userinfo;
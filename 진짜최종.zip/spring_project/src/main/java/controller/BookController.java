package controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import biz.book.dao.BookDAO;
import biz.book.service.BookService;

@Controller
public class BookController {
	
	@Autowired
	BookService service;
	@RequestMapping("/booklist.do")
	public String board(HttpServletRequest request) {
		String lib = request.getParameter("searchOption1");
		String ti = request.getParameter("searchOption2");
		String text = request.getParameter("search");
		HttpSession session = request.getSession();
		session.setAttribute("lib",lib);
		session.setAttribute("ti",ti);
		session.setAttribute("text",text);
		if(ti.equals("publisher")) {
			request.setAttribute("booklist", service.getBookList3(lib, text)); 
		} else if(ti.equals("author")) {
			request.setAttribute("booklist",service.getBookList2(lib, text));
		} else {
			System.out.println(ti);
			request.setAttribute("booklist",service.getBookList(lib, text));
		} 
		return "/book/book_list";
	}
	
	@RequestMapping(value = "/book.do", method = RequestMethod.GET)
	public ModelAndView book(int bookKey,int check) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("book", service.getBook(bookKey));
		mav.addObject("check",check);
		mav.setViewName("/book/book_view");
		return mav;
	}
}
create table userinfo (
	userid varchar2(15) primary key,
	username varchar2(20),
	userpwd varchar2(10),
	email varchar2(50),
	phone varchar2(15),
	address varchar2(100),
	userdate date default sysdate
);


create table board
(
    boardno   number(10) primary key,
    title     varchar2(100)  not null,
    content   varchar2(4000) not null,
    writer varchar2(15) references userinfo(userid),
    boarddate date   default sysdate,
    viewcount   number(10)
);

insert into userinfo (userid, username, userpwd, email, phone, address) values ('dlgodrk', '이철행', '8456456z', 'dlgodrk@naver.com', '010-9919-6005', '사가정');
select * from userinfo;


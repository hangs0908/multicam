package controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class BookController {
	@RequestMapping("/book.do")
	public String book() {
		return "book/book_list";
	}
	
	@RequestMapping("/board.do")
	public String board() {
		return "book/review";
	}
}

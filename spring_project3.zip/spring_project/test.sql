

create table userinfo (
	userid varchar2(15) primary key,
	username varchar2(20),
	userpwd varchar2(10),
	email varchar2(50),
	phone varchar2(15),
	address varchar2(100),
	userdate date default sysdate
);


create table board
(
    boardno   number(10) primary key,
    title     varchar2(150)  not null,
    content   varchar2(4000) not null,
    writer varchar2(15) references userinfo(userid),
    boarddate date   default sysdate,
    viewcount   number(10)
);

	insert into userinfo (userid, username, userpwd, email, phone, address) values ('dkdl8888', 'T없e맑은I','erer!23232','ii333@daum.net', '010-2323-4444' ,'서울시 강서구');
	insert into userinfo (userid, username, userpwd, email, phone, address) values ('sldms1221', '손흥민', 'tlfj@131','like444@daum.net', '010-1111-4444' ,'서울시 강북구');
	insert into userinfo (userid, username, userpwd, email, phone, address) values ('boom9898', '장미여신','anjgka123!', 'love2388@daum.net', '010-2323-4455' ,'서울시 종로구');
	insert into userinfo (userid, username, userpwd, email, phone, address) values ('gma3333', '뽀대작살', 'alal#999','dktk@naver.com', '010-9797-3434' ,'대전 유성구');
	insert into userinfo (userid, username, userpwd, email, phone, address) values ('hmmm22', 'simonD', 'dkssud@333','simon@naver.com', '010-5555-3543' ,'충북 영동군');
	insert into userinfo (userid, username, userpwd, email, phone, address) values ('zzizon52', 'Esens', 'qkqh9090!@', 'esens@naver.com', '' ,'부산 해운대구');
	insert into userinfo (userid, username, userpwd, email, phone, address) values ('dfewww22', '패션왕', 'yumyum1!', 'king@yahoo.com', '010-3425-4232' ,'서울시 강서구');
	insert into userinfo (userid, username, userpwd, email, phone, address) values ('hanana8944', 'S2러브천사S2','sjssjs9*', 'angel@naver.com', '010-5252-2221' ,'부산 서면');
	insert into userinfo (userid, username, userpwd, email, phone, address) values ('coding554', 'zl존코딩', 'nyo@3322','coder@naver.com', '010-6875-3423' ,'서울 동작구');
	insert into userinfo (userid, username, userpwd, email, phone, address) values ('pizzalover0101', '치킨나라피자공주', 'pilot3#', 'pizza@naver.com', '010-5555-1111' ,'부산 서면');
	insert into userinfo (uso;erid, username, userpwd, email, phone, address) values ('dlgodrk', '이철행', '8456456z', 'dlgodrk@naver.com', '010-9919-6005' ,'사가정');
select * from userinf
select * from book;
desc userinfo

drop table book;


create table book (
	bookno number(10) primary key,
	title varchar2(50),
	library varchar2(30),
	location varchar2(30),
	writer varchar2(50)
);


drop table board;

create table book(
    bookkey number primary key,
    libname varchar2(20) not null,
    managecode varchar2(5),
    title varchar2(100),
    author varchar2(20),
    publisher varchar2(20),
    pubyear varchar2(10),
    viewcount number default 0
);
drop table book;


create sequence seq_bookkey
    START WITH  1
    INCREMENT BY 1
    MAXVALUE 10000
    MINVALUE 1
    NOCYCLE;



create sequence seq_boardno
    START WITH  1
    INCREMENT BY 1
    MAXVALUE 10000
    MINVALUE 1
    NOCYCLE;

    insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '남산도서관', 'MH', '딥러닝과 바둑', '막스 펌펄라', '한빛미디어', '2020');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '남산도서관', 'MH', '거꾸로 읽는 철학이야기', '강성률', '글로벌콘텐츠', '2020');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '남산도서관', 'MH', '기억이 부푸는 속도', '김민지', '민음사', '2019');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '남산도서관', 'MH', '수학의 선물 : 수학을 하는 것과 인생을 사는 일의 공명에 관하여', '모리타 마사오', '원더박스', '2019');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '남산도서관', 'MH', '랩걸 : 나무, 과학 그리고 사랑', '호프 자런', '알마', '2018');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '노원평생학습관', 'MV', '(비전공자를 위한 이해할 수 있는) IT 지식', '최원영', '티더블유아이지', '2020');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '노원평생학습관', 'MV', '예술의 정의', '토머스 애더지안', '전기가오리', '2018');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '노원평생학습관', 'MV', '옛글의 풍경에 취하다', '조운찬', '역사공간', '2019');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '노원평생학습관', 'MV', '이상한 수학책 : 그림으로 이해하는 일상 속 수학 개념들', '벤 올린', '북라이프', '2020');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '노원평생학습관', 'MV', '총, 균, 쇠', '재레드 다이아몬드', '문학사상', '2019');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '도봉도서관', 'MJ', '3D프린팅을 활용한 시제작품 제작 마스터 실무', '최년식', '동화기술', '2019');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '도봉도서관', 'MJ', '풍경에 대하여 : 풍경으로 살아가기, 또는 이성이 지나친 것', '프랑수아 줄리앙', '아모르문디', '2016');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '도봉도서관', 'MJ', '문학의 기쁨', '금정연', '루페', '2017');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '도봉도서관', 'MJ', '속담으로 수학을 읽다', '이보경', '지브레인', '2020');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '도봉도서관', 'MJ', '인간의 흑역사', '톰 필립스', '윌북', '2019');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '동대문도서관', 'MK', 'UiPath 입문+활용 : 모두를 위한 RPA', '송순오', '앤써북', '2019');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '동대문도서관', 'MK', '동아시아 고전의 이해', '문현주', '경상대학교출판부', '2018');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '동대문도서관', 'MK', '작가들의 정원', '재키 베넷', '샘터사', '2015');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '동대문도서관', 'MK', '미생물이 플라톤을 만났을 때 : 생물학과 철학의 우아한 이중주', '김동규', '문학동네', '2019');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '동대문도서관', 'MK', '내 머리로 생각하는 역사 이야기', '유시민', '푸른나무', '2012');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '동작도서관', 'ML', '(4차 산업혁명시대) 핀테크 개인정보보호 = Industrial 4.0 fintech privacy policy : 핀테크 기업과 이용자를 위한 개인정보보호 핵심 가이드', '백남정', '지식플랫폼', '2019');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '동작도서관', 'ML', '프롤로그 에필로그 박완서의 모든 책', '박완서', '작가정신', '2020');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '동작도서관', 'ML', '영문학과 역사적 상상력', '여홍상', 'L.I.E', '2013');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '동작도서관', 'ML', '생명의 프린키피아', '김희수', '부산대학교출판부', '2019');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '동작도서관', 'ML', '자본의 재생산', '고병권', '천년의상상', '2020');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '마포평생아현분관', 'MX', 'Amazon Web Services 이야기', '최진식', '좋은땅', '2019');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '마포평생아현분관', 'MX', '한국고전문학 수업', '정병설', '서울대학교출판문화원', '2019');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '마포평생아현분관', 'MX', '공감적 상상력에서 생명의 시학으로', '김영무', '서울대학교출판문화원', '2011');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '마포평생아현분관', 'MX', '실험실 생활 : 과학적 사실의 구성', '브루노 라투르', '한울아카데미', '2019');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '마포평생아현분관', 'MX', '어려웠던 경제가 이렇게 쉬울 줄이야 : 경제를 1도 모르는 당신을 위한 생활 경제학', '가미키 헤이스케', '팬덤북스', '2020');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '마포평생학습관', 'MM', '(그림과 이야기로 쉽게 배우는) 소프트웨어와 코딩 첫걸음', '김현정', '궁리', '2018');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '마포평생학습관', 'MM', '안녕을 묻는 방식 : 양경언 평론집', '양경언', '창비', '2019');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '마포평생학습관', 'MM', '수학의 역사를 만든 놀라운 발견들', '로버트 스네덴', '북스힐', '2020');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '마포평생학습관', 'MM', '세상을 바꾼 생물 : 생물의 역사가 생명의 미래를 바꾼다!', '원정현', '리베르스쿨', '2018');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '마포평생학습관', 'MM', '폰 글란의 중국경제사', '리처드 폰 글란', '소와당', '2020');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '용산도서관', 'MS', '뉴스는 싫지만 호구도 되기 싫다 : 경제상식 편', '김보리', '황금부엉이', '2020');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '용산도서관', 'MS', '경제학자의 인문학 서재 : 경제학은 세상과 어떻게 연결되는가', '박정호', '더퀘스트', '2020');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '용산도서관', 'MS', '영어독서가 취미입니다 : 국어책 읽기만큼 쉬운 영어독서습관 만들기', '권대익', '반니라이프', '2020');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '용산도서관', 'MS', '영국 영어 이렇게 다르다', '고지인', '안나푸르나', '2019');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '용산도서관', 'MS', '유죄 오판 : 심리학의 교훈', 'Brian L. Cutler', '학지사', '2018');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '정독도서관', 'MT', '시장의 기억 : 한국의 자본시장은 어떻게 반복되는가', '이태호', '어바웃어북', '2020');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '정독도서관', 'MT', '임금에 관한 온갖 헛소리', '고병권', '천년의상상', '2020');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '정독도서관', 'MT', '한 권으로 끝내는 영어', '이호철', '북랩', '2019');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '정독도서관', 'MT', '세상에 속지 않는 법', '박남주', '부키', '2019');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '정독도서관', 'MT', '노터리어스 RBG', '아이린 카먼', '글항아리', '2016');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '종로도서관', 'MU', '맨큐의 경제학', 'N. Gregory Mankiw', '센게이지러닝코리아', '2019');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '종로도서관', 'MU', '더 팩토리 : 공장은 어떻게 인류의 역사를 바꿔왔는가', '조슈아 B. 프리먼', '시공사', '2019');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '종로도서관', 'MU', '잘하는 영어 말고 자라는 영어', '김주년', '북트리', '2019');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '종로도서관', 'MU', '판사유감', '문유석', '문학동네', '2019');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values (seq_bookkey.nextval, '종로도서관', 'MU', '(안병한 변호사가 들려주는) 생활법률 상식', '안병한', '부광', '2013');
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '서대문도서관', 'MP','랜선 인문학 여행 : 우리가 사랑하는 예술가들의 소울 플레이스를 동행하는 즐거움','박소영','한겨레출판','2020','0');
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '서대문도서관', 'MP','공부의 고전 : 스스로 배우는 방법을 익히기 위하여','에라스무스 유유','','2020','0');
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '서대문도서관', 'MP','공부의 고전 : 스스로 배우는 방법을 익히기 위하여','에라스무스 유유','','2020',0);
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '서대문도서관', 'MP','감정의 자화상 : 화가의 가슴에서 꺼내온 가장 내밀한 고백','박홍순 ','서해문집','2018',0);
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '서대문도서관', 'MP','다시 시작하는 독서 : 책장에 잠든 설렘을 깨우다','박홍순 ','비아북','2016',0);
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '서대문도서관', 'MP','남명천화상송증도가 : 세계 최초 금속활자본의 탄생','박상국 ','김영사','2020',0);
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '송파도서관', 'MW','책 만드는 책 : 북아트 & 북바인딩','서효정 ','이숲','2020',0);
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '송파도서관', 'MW','책기계 수집기 = Old press collection','김진섭 ','책공방','2019',0);
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '송파도서관', 'MW','기억과 기록 사이 : 어느 북 디자이너가 읽은 책과 만든 책','이창재','돌베개','2020',0);
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '송파도서관', 'MW','만날 읽으면서도 몰랐던 책 이야기','글: 구원경 ; 그림: 이동현','','2017',0);
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '송파도서관', 'MW','동아시아 금속활자 인쇄 문화의 창안과 과학성. 2','옥영정 외 지음','한국학중앙연구원출판부','2017',0);
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '양천도서관', 'MN','한국그림책 연감. 2016','원주문화재단 ','원주문화재단','2016',0);
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '양천도서관', 'MN','수사본의 역사와 이해 : 책과 예술의 만남','김대신 ','일진사','2012',0);
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '양천도서관', 'MN','(메이킹북) 교실 안 책만들기 활동의 실제','권성자 ','아이북','2011',0);
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '양천도서관', 'MN','열린책들 편집 매뉴얼. 2012 = (The) open books editorial manual','열린책들 ','열린책들','2012',0);
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '어린이도서관', 'MQ','사서선생님과 함께 학교도서관에서 수업하기 : 이용자교육부터 정보활용수업까지','한국학교도서관협의회 ','조은글터','2019',0);
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '어린이도서관', 'MQ','스토리타임의 기초','페니 펙 [지음] ; 정진욱 번역','국립어린이청소년도서관','2017',0);
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '어린이도서관', 'MQ','딥러닝과 바둑','막스 펌펄라 , 케빈 퍼거슨','한빛미디어','2020',0);
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '어린이도서관', 'MQ','(제4차 산업혁명 시대의) 사이버전 개론 = An introduction of cyber warfare : attack and security techniques','엄정호, 김남욱, 정태명','홍릉','2020',0);
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '어린이도서관', 'MQ','(백견불여일타) 딥러닝 입문 : with 텐서플로우 2.x','조휘용 ','로드북','2020',0);
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '영등포평생학습관', 'MR','인공지능과 테크놀로지',' 미야케 요이치로 감수','성안당','2020',0);
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '영등포평생학습관', 'MR','4차 산업혁명, 준비됐니)데이터로 과학하기','윤현집 ','탐','2020',0);
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '영등포평생학습관', 'MR','마인드스톰 : 어린이, 컴퓨터, 배움 그리고 강력한 아이디어','시모어 패퍼트 ','인사이트','2020',0);
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '영등포평생학습관', 'MR','세상에서 가장 아름다운 도서관','자크 보세 글 ; 기욤 드 로비에 사진','다빈치','2012',0);
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '영등포평생학습관', 'MR','친환경 녹색도서관','노영희','조은글터','2012',0);
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '용산도서관', 'MS','살아있는 도서관을 위한 인테리어 디자인','Carol R. Brown','국제','2004',0);
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '용산도서관', 'MS','기적의 도서관 : 정기용의 어린이 도서관','정기용 ','현실문화연구','2010',0);
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '용산도서관', 'MS','지식망','채희락, 이해윤, 김동훈','Huine','2018',0);
INSERT INTO book (bookkey, libname, managecode, title, author, publisher, pubyear, viewcount) VALUES (seq_bookkey.NEXTVAL, '용산도서관', 'MS','정보자원의 기술과 메타데이터 = Resource description and metadata','남태우, 이승민 ','한국도서관협회','2018',0);
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
( seq_bookkey.NEXTVAL,'강남도서관','MA','(라이트 형제) 자전거 수리공, 하늘을 날다','김은정', '그레이트북스', '2007');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
(seq_bookkey.NEXTVAL ,'강남도서관','MA','천문대의 시간 천문학자의 하늘','전영범 ', '에코리브르', '2018');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
(seq_bookkey.NEXTVAL ,'강남도서관','MA','윤동주 전 시집 : 윤동주 100주년 기념, 하늘과 바람과 별과 시','윤동주 ', '스타북스', '2019');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
( seq_bookkey.NEXTVAL,'강남도서관','MA','하늘에서 들려온 노래','차오원쉬엔 ', '스콜라', '2016');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
( seq_bookkey.NEXTVAL,'강남도서관','MA','비구름을 삼킨 하늘','이장상미 ', '모시는사람들', '2015');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
(seq_bookkey.NEXTVAL ,'강동도서관','MB','아이 러브 와플 = I love waffle : 쿠키보다 쉽고, 케이크보다 맛있다!','센 공원주', '미디어윌', '2011');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
(seq_bookkey.NEXTVAL ,'강동도서관','MB','도대체 누가 와플을 먹은 걸까?','션 테일러', '예원미디어', '2012');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
(seq_bookkey.NEXTVAL ,'강동도서관','MB','와플 똥','토레 렌베르그', '봄봄스쿨', '2014');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
(seq_bookkey.NEXTVAL ,'강동도서관','MB','큰곰','프랑수와 플라스', '솔출판사', '2007');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
( seq_bookkey.NEXTVAL,'강동도서관','MB','(공병호의) 고전강독. 2, 소크라테스와 플라톤에게 다시 정의를 묻다','공병호', '해냄', '2012');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
(seq_bookkey.NEXTVAL ,'강서도서관','MC','천연발효빵 만들기 : 두 번째 레시피','최화영', '크라운출판사', '2016');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
(seq_bookkey.NEXTVAL ,'강서도서관','MC','토끼 빵과 돼지 빵','오자와 다다시', '비룡소', '2012');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
( seq_bookkey.NEXTVAL,'강서도서관','MC','빵 자매의 빵빵한 여행 : 빵이라면 죽고 못 사는 빵 자매의 유럽여행','박미이', '이담 Books', '2019');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
(seq_bookkey.NEXTVAL ,'강서도서관','MC','독일 빵 대백과 : 정통 독일 빵의 모든 것','모리모토 토모코', 'BM성안당', '2018');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
(seq_bookkey.NEXTVAL ,'강서도서관','MC','(우리 식재료, 천연 재료로 만든) 김영모의 건강빵','김영모', '동아일보사', '2010');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
( seq_bookkey.NEXTVAL,'개포도서관','MD','아이스크림의 지구사','로라 B. 와이스', '휴머니스트 출판그룹', '2013');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
(seq_bookkey.NEXTVAL ,'개포도서관','MD','세상을 담은 아이스크림','전세라', '생각과느낌', '2010');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
(seq_bookkey.NEXTVAL ,'개포도서관','MD','아이스크림이 녹기 전에 : 진저 장편소설','진저', '자음과모음', '2018');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
(seq_bookkey.NEXTVAL ,'개포도서관','MD','일루와 아이스크림','윤재인', '느림보', '2019');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
(seq_bookkey.NEXTVAL ,'개포도서관','MD','아이스크림 메이커 : 에르네스트 판 데르 크바스트 장편소설','에르네스트 판 데르 크바스트', '세종서적', '2018');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
(seq_bookkey.NEXTVAL ,'고덕평생학습관','ME','이 배를 타길 정말 잘했어! : 어마어마하게 큰 배에 담긴 평화 이야기','박경화', '웃는돌고래', '2017');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
(seq_bookkey.NEXTVAL ,'고덕평생학습관','ME','배를 엮다 : 미우라 시온 장편소설','미우라 시온', '은행나무', '2013');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
(seq_bookkey.NEXTVAL ,'고덕평생학습관','ME','배를 만들고 싶은 조선 소년','허순영', '위즈덤하우스', '2019');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
(seq_bookkey.NEXTVAL ,'고덕평생학습관','ME','배가 아파요','이효상', '리젬', '2016');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
(seq_bookkey.NEXTVAL ,'고덕평생학습관','ME','바쁜 날에도 배는 고프다 : 히라마쓰 요코 에세이','히라마쓰 요코', '씨네21북스', '2016');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
(seq_bookkey.NEXTVAL ,'고척도서관','MF','샤오미 insight : 기획에서 마케팅까지, 샤오미의 모든 것','허옌', '예문', '2014');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
( seq_bookkey.NEXTVAL,'고척도서관','MF','샤오미처럼 = Xiaomi : 파괴적 혁신을 이끄는 스타트업 매뉴얼','반석지심', '책비', '2016');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
(seq_bookkey.NEXTVAL ,'고척도서관','MF','참여감 : 샤오미가 직접 공개하는 창의성과 혁신의 원천','리완창', '와이즈베리', '2015');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
(seq_bookkey.NEXTVAL ,'고척도서관','MF','음향영상설비 매뉴얼. 2003','SoundArt 편집부 편', '샤프랫뮤직', '2003');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
(seq_bookkey.NEXTVAL ,'고척도서관','MF','화가와 시인 : 보들레르 미학의 등대 들라크루아, 그에게 바치는 미술론','보들레르', '열화당', '2007');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
(seq_bookkey.NEXTVAL ,'구로도서관','MG','소방전기기초','강성화', '신광문화사', '2003');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
(seq_bookkey.NEXTVAL ,'구로도서관','MG','아로마향초 만들기','캔들크래프트', '어드북스', '2008');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
(seq_bookkey.NEXTVAL ,'구로도서관','MG','초서(抄書) 독서법 : 읽고 가려 뽑아 내 글로 정리하는 힘','김병완', '청림출판', '2019');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
( seq_bookkey.NEXTVAL,'구로도서관','MG','고맙다 잡초야 : 야생초 편지 두 번째 이야기','황대권', '도솔', '2012');
insert into book(bookkey, libname, managecode, title, author, publisher, pubyear) values 
( seq_bookkey.NEXTVAL,'구로도서관','MG','(메카트로닉스공학도를 위한) 기초전기전자실습','이상경', '내하출판사', '2013');
